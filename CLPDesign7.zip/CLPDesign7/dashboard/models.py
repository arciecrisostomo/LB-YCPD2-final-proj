from django.db import models
from django.core.validators import MinValueValidator

# Create your models here.
class Order(models.Model):
    products = models.CharField(max_length=100)
    quantity = models.IntegerField(validators=[MinValueValidator(1)])
    customerName = models.CharField(max_length=200)
    contactInfo = models.CharField(max_length=20)
    shippingLocation = models.CharField(max_length=200)
    courier = models.CharField(max_length=50)
    shippingRef = models.CharField(max_length=50)
    additionalExpenses = models.DecimalField(max_digits=100, decimal_places=2)
    user = models.CharField(max_length=100, editable=False)