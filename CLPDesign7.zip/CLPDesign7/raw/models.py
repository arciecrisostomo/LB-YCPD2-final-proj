from django.db import models
from django.forms import ModelForm
from django.core.validators import MinValueValidator
from django.core import validators


# Create your models here.
# from raw.forms import check_raw_prod


class Raw(models.Model):
    name = models.CharField(max_length=200)
    materialType = models.CharField(max_length=200)
    quantity = models.DecimalField(decimal_places=0, max_digits=100)
    unitType = models.CharField(max_length=200)
    totalCost = models.DecimalField(decimal_places=2, max_digits=100)


class Initial(models.Model):
    user = models.CharField(max_length=100, editable=False)
    name = models.CharField(max_length=200)
    materialType = models.CharField(max_length=200)
    # quantity = models.DecimalField(decimal_places=0, max_digits=100)
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unitType = models.CharField(max_length=200)
    totalCost = models.DecimalField(decimal_places=2, max_digits=100)

    def __str__(self):
        return self.name


class InitialPR(models.Model):
    unit_type_choices = [
        ('Packing', (
            ('pc', 'Piece'),
            ('6pack', '6-Pack'),
            ('dozen', 'Dozen')
        )),
        ('Volume', (
            ('tsp', 'Teaspoon'),
            ('tbsp', 'Tablespoon'),
            ('cup', 'Cup'),
            ('pt', 'pint'),
            ('qt', 'Quart'),
            ('gal', 'Gallon'),
            ('ml', 'Milliliter'),
            ('liter', 'Liter')
        )),
        ('Weight', (
            ('lb', 'Pound'),
            ('oz', 'Ounce'),
            ('mg', 'Milligram'),
            ('gram', 'Gram'),
            ('kg', 'Kilogram')
        )),
        ('Length', (
            ('in', 'Inch'),
            ('ft', 'Feet'),
            ('yd', 'Yard'),
            ('mm', 'Millimeter'),
            ('cm', 'Centimeter'),
            ('meter', 'Meter')
        ))
    ]
    user = models.CharField(max_length=100, editable=False)
    product = models.CharField(max_length=100, editable=False)
    name = models.CharField(max_length=200)
    materialType = models.CharField(max_length=200)
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unitType = models.CharField(max_length=200, choices=unit_type_choices)
    totalCost = models.DecimalField(decimal_places=2, max_digits=100)





    def __str__(self):
        return self.name
