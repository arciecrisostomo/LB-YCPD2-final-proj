from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from raw.models import Initial
from raw.forms import RawForm
from .models import *

# from raw.models import Initial
from .forms import RawFormPR
from raw.models import InitialPR
from products.models import Initial
from django.db.models import Count

def raw_database_view(request, *args, **kwargs):
    # raw = Initial.objects.all()
    raw = InitialPR.objects.all()
    return render(request, "view_raw_database.html", {'raw': raw})

# Create your views here.
def new_raw_view(request):
    allRaw = InitialPR.objects.all()
    product = Initial.objects.latest('id')
    # product = Initial.objects.order_by('name').first()
    # A
    # B
    # C
    form = RawFormPR(request.POST or None, request.FILES or None)

    if request.method == 'POST':
        if 'finishButton' in request.POST:
            if form.is_valid:
                # for initialPR in allRaw:
                # if InitialPR.user == request.user.username:
                #         if InitialPR.objects.filter(product=product).count() > 0:
                #             messages.error(request, 'raw material exists')
                #         else:
                #     querysetC = InitialTwo.objects.values('customerName').annotate(frequency=Count('customerName'))


                if InitialPR.objects.filter(name=request.POST.get('name')).count() > 0 or InitialPR.objects.filter(
                        name=request.POST.get('product')).count() > 0:
                    messages.error(request, 'Raw material under the same product already exists.')

                elif InitialPR.objects.filter(name=request.POST.get('name')).count() > 0 and InitialPR.objects.filter(
                        name=request.POST.get('product')).count() > 0:
                    messages.error(request, 'Raw material under the same product already exists.')

                else:
                    fs = form.save(commit=False)
                    fs.user = request.user
                    fs.product = product
                    fs.save()
                    return redirect('home')

            else:
                messages.error("Error")

        # if add more raw materials button is clicked
        else:
            if form.is_valid:

                # print(Initial.objects.all().last())
                # print(Initial.objects.all())
                # for i in Initial.objects.all():
                #     print(i.product)
                #     if i.name == str((request.POST.get('name'))):
                #         print('product: ' + i.name + 'rm: ' + str(request.POST.get('name')))

                # InitialPR.objects.values('product').annotate(frequency=Count('product')).count() >

                # for i in InitialPR.objects.order_by(('name')):
                #     if str(i).lower() == str(request.POST.get('name')).lower():
                #         for j in Initial.objects.all():
                #             if str(j).lower() == str(product).lower():
                #                 print(str(InitialPR.objects.filter(product=j).first()))
                #                 print(product)
                #                 break
                        # print('raw mat exists')
                        # print(str(request.POST.get('name')))
                        # # print(str(InitialPR.objects.order_by('name')))
                        # print(str(product).lower())
                    # else:
                    #     continue
                # else:
                # print(InitialPR.objects.order_by('name')[0])
                # print(str(request.POST.get('name')))
                # if InitialPR.user == request.user.username:
                if InitialPR.objects.filter(name=request.POST.get('name')).count() > 0 or InitialPR.objects.filter(name=request.POST.get('product')).count() > 0:
                    messages.error(request, 'Raw material under the same product already exists.')

                elif InitialPR.objects.filter(name=request.POST.get('name')).count() > 0 and InitialPR.objects.filter(name=request.POST.get('product')).count() > 0:
                    messages.error(request, 'Raw material under the same product already exists.')

                else:
                    fs = form.save(commit=False)
                    fs.user = request.user
                    fs.product = product
                    fs.save()
                    return redirect('new_raw')

            else:
                messages.error("Error")
                # return render(request, 'add_raw.html')

    context = {'form': form, 'allRaw': allRaw}
    return render(request, "add_raw.html", context)




    # allRaw = Initial.objects.all()
    # form = RawForm(request.POST or None, request.FILES or None)
    #
    # if request.method == 'POST':
    #     if 'finishButton' in request.POST:
    #         if form.is_valid:
    #             fs = form.save(commit=False)
    #             fs.user = request.user
    #             fs.save()
    #             return redirect('home')
    #
    #         else:
    #             messages.error("Error")
    #
    #     #if add more raw materials button is clicked
    #     else:
    #         if form.is_valid:
    #             fs = form.save(commit=False)
    #             fs.user = request.user
    #             fs.save()
    #             return redirect('new_raw')
    #
    #         else:
    #             messages.error("Error")
    #             # return render(request, 'add_raw.html')
    #
    # context = {'form': form, 'allRaw': allRaw}
    # return render(request, "add_raw.html", context)












     # if request.method == 'POST':
     #     # form = RawForm(request.POST)
     #     # if form.is_valid():
     #     if 'finishButton' in request.POST:
     #        if request.POST.get('name') and request.POST.get('materialType') and request.POST.get('quantity') and request.POST.get('unitType') and request.POST.get('totalCost'):
     #            saveRecord = Initial()
     #            saveRecord.name = request.POST.get('name')
     #            saveRecord.materialType = request.POST.get('materialType')
     #            saveRecord.quantity = request.POST.get('quantity')
     #            saveRecord.unitType = request.POST.get('unitType')
     #            saveRecord.totalCost = request.POST.get('totalCost')
     #            saveRecord.save()
     #            # return render(request, 'home.html')
     #            return redirect('home')
     #
     #        else:
     #            messages.error("Error")
     #
     #     else:
     #        if request.POST.get('name') and request.POST.get('materialType') and request.POST.get('quantity') and request.POST.get('unitType') and request.POST.get('totalCost'):
     #            saveRecord = Initial()
     #            saveRecord.name = request.POST.get('name')
     #            saveRecord.materialType = request.POST.get('materialType')
     #            saveRecord.quantity = request.POST.get('quantity')
     #            saveRecord.unitType = request.POST.get('unitType')
     #            saveRecord.totalCost = request.POST.get('totalCost')
     #            saveRecord.save()
     #
     #            return redirect('new_raw')
     #
     #        else:
     #            messages.error("Error")
         #        return render(request, 'add_raw.html')

     # else:
         # return render(request, "add_raw.html")
         # return redirect('new_raw')


     # context = {}
     # return render(request, "add_raw.html", context)

def view_edit_raw(request):
    # raw = Initial.objects.all()
    raw = InitialPR.objects.all()
    return render(request, "view_edit_raw.html", {'raw': raw})

def edit_raw_view(request, pk):
    # raw = Initial.objects.get(id=pk)
    raw = InitialPR.objects.get(id=pk)


    form = RawForm(instance=raw)

    if request.method == 'POST':
        form = RawForm(request.POST, instance=raw)
        if 'finishButton' in request.POST:
            if form.is_valid():
                form.save()
                return redirect('home')
        else:
            if form.is_valid():
                form.save()
                return redirect('home')

    context = {'form': form}
    return render(request, "add_raw.html", context)

def view_delete_raw(request):
    # raw = Initial.objects.all()
    raw = InitialPR.objects.all()

    return render(request, "view_delete_raw.html", {'raw': raw})

def delete_raw_view(request, pk):
    # raw = Initial.objects.get(id=pk)
    raw = InitialPR.objects.get(id=pk)

    if request.method == 'POST':
        if 'cancel' not in request.POST:
            raw.delete()
        return redirect('home')

    context = {'item': raw}
    return render(request, "delete_raw.html", context)
