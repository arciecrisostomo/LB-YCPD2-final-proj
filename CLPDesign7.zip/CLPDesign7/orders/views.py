from django.shortcuts import render, redirect
from orders.models import InitialTwo
from django.contrib import messages
from products.models import Initial

from products.forms import ProductsForm
from .forms import OrdersForm
from orders.models import InitialTwo
from orders.forms import OrdersForm
from .models import *
from .forms import OrdersForm
from products import *
# from orders.models import InitialTwo
from django.db.models import Count
from django.views.generic import CreateView
from django.urls import reverse_lazy
from products.models import Initial
#


def sold_products_view(request, *args, **kwargs):
    orders = InitialTwo.objects.all()
    return render(request, "view_sold_database.html", {'orders': orders})

# Create your views here.
# def add_order(request, *args, **kwargs):
#     return render(request, "add_order.html", {})

# class add_order(CreateView):
#     model = InitialTwo
#     fields = '__all__'
#     success_url = reverse_lazy('add_order.html')


def add_order(request):

    # print(InitialTwo.objects.filter(user=request.user))
    allOrders = InitialTwo.objects.all()

    form = OrdersForm(request.POST or None, request.FILES or None)

    from django.db.models import Count
    if form.is_valid():

        # if InitialTwo.user == request.user.username:
        #     if Initial.objects.values((request.POST.get('products'))).annotate(frequency=Count(request.POST.get('name'))).count() > 0:

        fs = form.save(commit=False)
        # fs.products = request.products
        fs.user = request.user
        fs.save()
        return redirect('home')

    # products = Initial.obj.values('name')

    context = {'form': form, 'allOrders': allOrders}
    return render(request, "add_order.html", context)

    # form = OrdersForm()
    # if request.method == 'POST':
    #     form = OrdersForm(request.POST)
    #     if form.is_valid():
    #         form.save()
    #         return redirect('home')
    #
    # context = {'form': form}
    # return render(request, "add_order.html", context)
