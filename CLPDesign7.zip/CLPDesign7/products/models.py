from django.db import models
# from django.utils.functional import curry
from functools import partial as curry

# Create your models here.
class Product(models.Model):
    name = models.CharField(max_length=200)
    itemType = models.CharField(max_length=200)
    sellPrice = models.DecimalField(decimal_places=2, max_digits=100)


class Initial(models.Model):
    # User = settings.AUTH_USER_MODEL
    # user = models.ForeignKey(User, null=True)
    user = models.CharField(max_length=100, editable=False)
    name = models.CharField(max_length=200)
    itemType = models.CharField(max_length=200)
    sellPrice = models.DecimalField(decimal_places=2, max_digits=100)

    def __str__(self):
        return self.name

    # Can be used for tooltip text retrieval in html

    def _get_help_text(self, field_name):
        for field in self._meta.fields:
            if field.name == field_name:
                return field.help_text

    def __init__(self, *args, **kwargs):
        super(Initial, self).__init__(*args, **kwargs)
        
        for field in self._meta.fields:
            method_name = "get_{0}_help_text".format(field.name)

            curried_method = curry(self._get_help_text, field_name=field.name)

            setattr(self, method_name, curried_method)


    # def __init__(self, *args, **kwargs):
    #     super(Initial, self).__init__(*args, **kwargs)
    #     for i in self.field_names:
    #         help_text = self.field_names[i].help_text
    #         self.field[i].help_text = None
    #         if help_text != '':
    #             self.field_name[i].widget.attrs.update({'class': 'has-popover', 'data-content': help_text, 'data'
    #                                                                                                        '-placement': 'right',
    #                                                     'data-container': 'body'})
