from django.db.models import F
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from products.models import Initial
from products.forms import ProductsForm
from .models import *
from .forms import ProductsForm
from raw.models import InitialPR
from django.db.models import Count

# Create your views here.
# def new_product_view(request):
#     # if request.method == 'POST':
#         # form = ProductsForm(request.POST)
#         # if form.is_valid():
#     # form = ProductsForm()
#
#         # if request.POST.get('name') and request.POST.get('itemType') and request.POST.get('sellPrice'):
#         #     saverecord = Initial()
#         #     saverecord.name = request.POST.get('name')
#         #     saverecord.itemType = request.POST.get('itemType')
#         #     saverecord.sellPrice = request.POST.get('sellPrice')
#         #     saverecord.save()
#         #
#         #     return redirect('new_raw')
#         #
#         # else:
#             messages.error(request, 'Fill up errthang')
#             # return HttpResponseRedirect('/new_raw/')
#
#     # else:
#         # form = ProductsForm()
#
#     # return render(request, 'add_product.html', {'form': form})
#     form = ProductsForm()
#
#     context = {'form':form}
#
#     return render(request, "add_product.html", context)

def existing_products_view(request):
    products = Initial.objects.all()
    return render(request, "view_products_database.html", {'products': products})

def new_product_view(request):
    allProducts = Initial.objects.all()

    form = ProductsForm(request.POST or None, request.FILES or None)

    # for i in allProducts:
    #     if i.product == request.product:
    #         raise forms.ValidationError(str(i.product) + ' already exists')

    if form.is_valid():
        # InitialTwo.objects.values('customerName').annotate(frequency=Count('customerName'))

        # if Initial.user == request.user.username:
        #     if request.POST.get('name') in Initial.objects.all():
        #         messages.info(request, 'Product already exists.')
        #     else:
        fs = form.save(commit=False)

        fs.user = request.user
        fs.save()
        return redirect('new_raw')

    context = {'form': form, 'allProducts': allProducts}
    return render(request, "add_product.html", context)

def view_edit_product(request):
    products = Initial.objects.all()
    return render(request, "view_edit_product.html", {'products': products})

def edit_product_view(request, pk):
    product = Initial.objects.get(id=pk)
    # oldName = str(product)
    # # old
    # raw = InitialPR.objects.filter(product=product)
    # print(raw.first())

    form = ProductsForm(instance=product)

    if request.method == 'POST':
        form = ProductsForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            # newName = Initial.objects.get(id=pk)
            # raw2 = InitialPR.objects.filter(name=oldName)
            # item is product in raw

            # for x in raw:
            #     print(str(x.product) + " " + oldName)
            #     if str(x.product) == oldName:
            #         print('if')
                    # TBC..
                    # InitialPR.objects.filter(product=oldName).update(product=F())
                    # temp = InitialPR.objects.filter(product=oldName).first()
                    # temp = newName

            # form.save()
            # new
            # print(newName)

            return redirect('home')

    context = {'form': form}
    return render(request, "add_product.html", context)

def view_delete_product(request):
    products = Initial.objects.all()
    return render(request, "view_delete_product.html", {'products': products})

def delete_product_view(request, pk):
    product = Initial.objects.get(id=pk)
    raw = InitialPR.objects.filter(product=product)
    if request.method == 'POST':
        if 'cancel' not in request.POST:
            # item is product in raw
            for item in raw:
                if str(item.product) == str(product):
                    rawD = InitialPR.objects.filter(product=item.product).first()
                    rawD.delete()

            product.delete()
            return redirect('home')

    context = {'item': product}
    return render(request, "delete_product.html", context)
