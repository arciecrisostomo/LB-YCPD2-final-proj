from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from login import views
from products.models import Product
import json

from orders.models import InitialTwo

from collections import Counter

from django.db.models import Count

from products.models import Initial
from raw.models import InitialPR

# Create your views here.
def home_view(request):

    # for i in len(InitialTwo.objects.filter(user=request.user).values_list('products'))
    net = 0
    TAX = 0
    profit = 0
    if InitialTwo.objects.all().count() > 0:
        sellPriceTax = float(str(Initial.objects.filter(user=request.user).values_list('sellPrice', flat=True)[0]))
        totalCostTax = float(InitialPR.objects.filter(user=request.user, product=Initial.objects.filter(user=request.user)[0]).values_list('totalCost', flat=True)[0])
        additionalExpTax = float(InitialTwo.objects.filter(user=request.user, products=Initial.objects.filter(user=request.user)[0]).values_list('additionalExpenses', flat=True)[0])

    # testSell = Initial.objects.filter(user=request.user).values_list('sellPrice', flat=True)
    # testCost = 0
    # testExp = 0
    # for purchase in testSell:
    #     # lists
    #     testCost += float(InitialPR.objects.filter(user=request.user, products=purchase.values_list('totalCost', flat=True)[testSell.index(purchase)]))
    #     testExp += float(InitialTwo.objects.filter(user=request.user, products=purchase.values_list('additionalExpenses', flat=True)[testSell.index(purchase)]))

    # print(testCost)
    # print(testExp)
        tempNet = sellPriceTax - (totalCostTax + additionalExpTax)
        net = round(tempNet, 2)
        TAX = round(abs(net*0.12), 2)
        profit = round(net - TAX, 2)

    # print(net)
    # print(sellPriceTax)
    # print(totalCostTax)
    # print(additionalExpTax)

    # product=Initial.objects.filter(user=request.user).values_list('product', flat=True).
    # print(sellPriceTax + totalCostTax + " hi~")
    # print(sellPriceTax + " hi)

    labelsQ = []
    dataQ = []

    querysetQ = InitialTwo.objects.order_by('-quantity')
    for initial in querysetQ:
        if initial.user == request.user.username:
            if initial.products not in labelsQ:
                labelsQ.append(initial.products)
                dataQ.append(initial.quantity)
            elif initial.products in labelsQ:
                dataQ[labelsQ.index(initial.products)] += initial.quantity

    # maximum = max(dataQ)
    # maximum_index = dataQ.index(maximum)
    # most = labelsQ[maximum_index]

    labelsC = []
    dataC = []

    # queryset = InitialTwo.objects.values('customerName').annotate(country_population=Sum('population')).order_by(
    #     '-country_population')
    # for entry in queryset:
    #     labels.append(entry['country__name'])
    #     data.append(entry['country_population'])
    #
    #AB = InitialTwo.objects.order_by('customerName')

    AB = InitialTwo.objects.values('customerName').annotate(frequency=Count('customerName'))
    # print(AB)
    # print(AB.count())

    # for initial in querysetQ:
    #     print(initial.user)
    #     break

    for initial in querysetQ:
        # if InitialTwo.objects.order_by('customerName').first().user == request.user.username:
        if initial.user == request.user.username:
            querysetC = InitialTwo.objects.values('customerName').annotate(frequency=Count('customerName'))

            querysetC = str(querysetC).replace("<QuerySet [", "").replace("'customerName': ", "").replace(", 'frequency'","").replace("]>","").replace("}, {", ", ").replace("'", "\"")
            dict_test = json.loads(querysetC)

            # print(dict_test)
            # print(initial.user)
            # print(request.user.username)

            for key, value in dict_test.items():
                labelsC.append(key)
                dataC.append(value)

            break




    # print(labelsQ)
    # print(labelsC)
    # for i in dict_test.keys():
    #     labelsC.append(i)
    #
    # for j in dict_test.values():
    #     dataC.append(j)

    # if initial.user == request.user.username:
    #     for key, value in dict_test.items():
    #         labelsC.append(key)
    #         dataC.append(value)
    # selling price - (total cost + additional expenses) = net
    # FIND SOLD PRODUCTS IN TRANS TABLE (check)
    # THEN GET EACH SOLD PRODUCT'S SELLING PRICE FR PRODUCTS TABLE
    # TOTAL COST IS FR RAW TABLE
    # ADDITIONAL EXPENSES IS FR TRANS TABLE

    dateZ = []
    custZ = []

    dateTemp = InitialTwo.objects.values_list('date')
    # dateTemp = (splat[0] + "-" + splat[1] + "-" + splat[2]).replace(" ", "")
    # print((splat[0] + "-" + splat[1] + "-" + splat[2]).replace(" ", ""))
    # print(list(set(dateZ)))



    custTemp = InitialTwo.objects.values_list('customerName')
    custTemp = str(custTemp).replace("<QuerySet [", "").replace("(", "").replace(")", "").replace(",]>", "").replace(",,", ",").replace("' ", "'").replace("'", "")

    split_custTemp = custTemp.split(", ")
    # print(split_custTemp)

    for date in dateTemp:
        if split_custTemp[list(dateTemp).index(date)] not in custZ:
            splat = str(date).split('(')[2].split(',')
            dateZ.append((splat[0] + "-" + splat[1] + "-" + splat[2]).replace(" ", ""))
            custZ.append(split_custTemp[list(dateTemp).index(date)])

    # print(dateZ)
    # print(custZ)
    # for i in split_custTemp:
    #     custZ.append(icustZ

    # print(setDate)
    # print(setCust)




    solds = InitialTwo.objects.values_list('products')
    solds = str(solds).replace("<QuerySet [", "").replace("(","").replace(")","").replace(",]>","").replace(",,",",").replace("' ","'").replace("'","")

    split_solds = solds.split(", ")
    # print(split_solds)


    products = Initial.objects.values_list('name')
    products = str(products).replace("<QuerySet [", "").replace("(","").replace(")","").replace(",]>","").replace(",,",",").replace("' ","'").replace("'","")

    split_products = products.split(", ")
    # print(split_products)










    # for key, value in dict_test.keys(), dict_test.values():
    #     labelsC.append(key)
    #     dataC.append(value)
    # print(labelsC)
    # print(dataC)
    # for key, value in dict_test:
    #     labelsC.append(key)
    #     dataC.append(value)
    #
    # print(labelsC)
    # print(dataC)
    # count = Counter(querysetC)
    # print(count)

    # for i in querysetC:
    #     labelsC.append(i.customerName)
    #     dataC.append(i.customerName.count())

    # querysetC.most_common()
    #
    # for i, j in querysetC.most_common:
    #     print(i, j)

    # test = Counter(querysetC)
    # print(test)
    # test.
    # print(querysetC)

    # count = Counter(querysetC)
    # #
    # for i, j in count.items():
    #     print(i, j)
    # labelsC = count.keys()
    # dataC = count.values()

    # for initial in querysetC:
    #     dataC.append(querysetC.count(initial))
    #
    #     if initial.customerName not in querysetC:
    #         labelsC.append(initial.customerName)



    return render(request, 'home.html', {
        'labelsQ': labelsQ,
        'dataQ': dataQ,
        'labelsC': labelsC,
        'dataC': dataC,
        # 'most': most,
        'custZ': custZ,
        'dateZ': dateZ,
        'net': net,
        'TAX': TAX,
        'profit': profit
    })

    # return render(request, "test.html", {})


def item_relation_view(request):
    obj = Product.objects.get(id=1)

    context = {
        'Number': obj.idNum,
        'Name': obj.name,
        'Type': obj.itemType
    }

    return render(request, "item_relation.html", context)


def price_adjustment_view(request, *args, **kwargs):
    # return HttpResponse("<h1>Material Price</h1>")
    return render(request, "price_adjustment.html", {})


def about_us(request, *args, **kwargs):
    return render(request, "about_us.html", {})
