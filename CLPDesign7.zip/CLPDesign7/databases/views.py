from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from products.models import Initial
# from raw.models import Initial

# Create your views here.
# def sold_products_view(request, *args, **kwargs):
#     return render(request, "view_sold_database.html", {})


# def existing_products_view(request, *args, **kwargs):
#     return render(request, "view_products_database.html", {})

# def existing_products_view(request):
#     products = Initial.objects.all()
#     return render(request, "view_products_database.html", {'products': products})


# def raw_database_view(request, *args, **kwargs):
#     # raw = Initial.objects.all()
#     # return render(request, "view_raw_database.html", {'raw': raw})